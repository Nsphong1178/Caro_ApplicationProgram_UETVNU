﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Caro
{
    public partial class Choose : Form
    {
        public Choose()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();

            // Hiển thị Form1
            form1.Show();

            // Đóng form hiện tại (trong trường hợp này là form Main)
            this.Hide();
        }

        private GomokuGame gomokuGameForm;

        private void button2_Click(object sender, EventArgs e)
        {
            // Khởi tạo form GomokuGame nếu nó chưa được tạo
            if (gomokuGameForm == null)
            {
                gomokuGameForm = new GomokuGame();
                gomokuGameForm.FormClosed += GomokuGameForm_FormClosed; // Đăng ký sự kiện FormClosed
            }

            gomokuGameForm.Show(); // Hiển thị form GomokuGame
            this.Hide(); // Ẩn form hiện tại
        }

        private void GomokuGameForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Đặt lại tham chiếu đến form GomokuGame khi form GomokuGame đã đóng
            gomokuGameForm = null;
            this.Show(); // Hiển thị lại form chính khi form GomokuGame đã đóng
        }
    }
}
